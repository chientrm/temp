return {
  ["workshop-1880010952"]={
    configuration_options={ Seed=false, s1=1, s10=8, s2=6, s3=2, s4=5, s5=9, s6=3, s7=2, s8=3, s9=1 },
    enabled=true 
  } 
}